package cz.cvut.fit.niam1.grpc.server;

import cz.cvut.fit.niam1.grpc.*;

import cz.cvut.fit.niam1.grpc.flight.*;
import cz.cvut.fit.niam1.grpc.model.ToursServiceGrpc;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.protobuf.services.ProtoReflectionService;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FlightServiceServer extends ToursServiceGrpc.ToursServiceImplBase{

    private static List<FlightBooking> bookings = new ArrayList<>();

    public static void main(String[] args) throws IOException, InterruptedException {
        FlightServiceServer flightServiceServer = new FlightServiceServer();
        flightServiceServer.start();
        flightServiceServer.blockUntilShutdown();
    }

    private Server server;

    private void start() throws IOException {
        int port = 50051;
        server = ServerBuilder.forPort(port)
                .addService(new FlightServiceImpl())
                .addService(ProtoReflectionService.newInstance())
                .build()
                .start();
        System.out.println("Server started, listening on " + port);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.err.println("*** shutting down gRPC server since JVM is shutting down");
            FlightServiceServer.this.stop();
            System.err.println("*** server shut down");
        }));
    }

    private void stop() {
        if (server != null) {
            server.shutdown();
        }
    }

    private void blockUntilShutdown() throws InterruptedException {
        if (server != null) {
            server.awaitTermination();
        }
    }

    @GrpcService
    @SpringBootApplication
    static class FlightServiceImpl extends FlightServiceGrpc.FlightServiceImplBase {
        @Override
        public void listBookings(ListBookingsRequest request, StreamObserver<ListBookingsResponse> responseObserver) {
            ListBookingsResponse response = ListBookingsResponse.newBuilder().addAllBookings(bookings).build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }

        @Override
        public void addBooking(AddBookingRequest request, StreamObserver<AddBookingResponse> responseObserver) {
            FlightBooking newBooking = request.getBooking().toBuilder().setId(String.valueOf(bookings.size() + 1)).build();
            bookings.add(newBooking);
            AddBookingResponse response = AddBookingResponse.newBuilder().setMessage("Booking added successfully").build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }

        @Override
        public void removeBooking(RemoveBookingRequest request, StreamObserver<RemoveBookingResponse> responseObserver) {
            String bookingId = request.getId();
            boolean removed = bookings.removeIf(booking -> booking.getId().equals(bookingId));
            RemoveBookingResponse response;
            if (removed){
                response = RemoveBookingResponse.newBuilder().setMessage("Booking removed successfully").build();
            }
            else{
                response = RemoveBookingResponse.newBuilder().setMessage("Id not found.").build();
            }
            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }

        @Override
        public void updateBooking(UpdateBookingRequest request, StreamObserver<UpdateBookingResponse> responseObserver) {
            FlightBooking updatedBooking = request.getBooking();
            int index = -1;
            for (int i = 0; i < bookings.size(); i++) {
                if (bookings.get(i).getId().equals(updatedBooking.getId())) {
                    index = i;
                    break;
                }
            }
            if (index != -1) {
                bookings.set(index, updatedBooking);
                UpdateBookingResponse response = UpdateBookingResponse.newBuilder().setMessage("Booking updated successfully").build();
                responseObserver.onNext(response);
            } else {
                UpdateBookingResponse response = UpdateBookingResponse.newBuilder().setMessage("Booking not found").build();
                responseObserver.onNext(response);
            }
            responseObserver.onCompleted();
        }
    }
}
