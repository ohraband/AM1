package cz.cvut.fit.niam1.grpc.server;

import cz.cvut.fit.niam1.grpc.*;

import cz.cvut.fit.niam1.grpc.flight.*;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;

public class FlightServiceClient {

    public static void main(String[] args) {
        FlightServiceGrpc.FlightServiceBlockingStub stub = FlightServiceGrpc.newBlockingStub(
                ManagedChannelBuilder.forAddress("localhost", 50051)
                        .usePlaintext()
                        .build()
        );

        try {
            //Check the initial state
            System.out.println("Initial State:");
            listBookings(stub);

            //Add a new booking
            FlightBooking newBooking = FlightBooking.newBuilder()
                    .setPassenger(Passenger.newBuilder().setName("John Doe").setPassportNumber("420123456789").build())
                    .setDepartureAirport(Airport.newBuilder().setCode("LAX").build())
                    .setArrivalAirport(Airport.newBuilder().setCode("ORD").build())
                    .setDepartureDate("2023-01-01")
                    .setArrivalDate("2023-01-02")
                    .build();
            addBooking(stub, newBooking);

            //Check the state after adding a booking
            System.out.println("State after adding a booking:");
            listBookings(stub);

            //Update the booking
            FlightBooking updatedBooking = newBooking.toBuilder().setId("1").setPassenger(Passenger.newBuilder().
                    setName("Updated Doe").setPassportNumber("11111111").build()).build();
            updateBooking(stub, updatedBooking);

            //Check the state after updating the booking
            System.out.println("State after updating the booking:");
            listBookings(stub);

            //Remove the booking
            removeBooking(stub, "1");
            } catch (StatusRuntimeException e) {
                System.err.println("RPC failed: " + e.getStatus());
            }

            //Check the state after removing the booking
            System.out.println("State after removing the booking:");
            listBookings(stub);
    }

    private static void listBookings(FlightServiceGrpc.FlightServiceBlockingStub stub) {
        ListBookingsResponse response = stub.listBookings(ListBookingsRequest.newBuilder().build());
        for (FlightBooking booking : response.getBookingsList()) {
            System.out.println(booking);
        }
    }

    private static void addBooking(FlightServiceGrpc.FlightServiceBlockingStub stub, FlightBooking booking) {
        AddBookingResponse response = stub.addBooking(AddBookingRequest.newBuilder().setBooking(booking).build());
        System.out.println("Add Response: " + response.getMessage());
    }

    private static void updateBooking(FlightServiceGrpc.FlightServiceBlockingStub stub, FlightBooking booking) {
        UpdateBookingResponse response = stub.updateBooking(UpdateBookingRequest.newBuilder().setBooking(booking).build());
        System.out.println("Update Response: " + response.getMessage());
    }

    private static void removeBooking(FlightServiceGrpc.FlightServiceBlockingStub stub, String bookingId) {
        RemoveBookingResponse response = stub.removeBooking(RemoveBookingRequest.newBuilder().setId(bookingId).build());
        System.out.println("Remove Response: " + response.getMessage());
    }
}
