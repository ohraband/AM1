package cz.cvut.fit.niam1.grpc.server;

import cz.cvut.fit.niam1.grpc.payment.*;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;


public class PaymentServiceClient {

    public static void main(String[] args) {
        // Create a channel and a stub
        PaymentServiceGrpc.PaymentServiceBlockingStub stub = PaymentServiceGrpc.newBlockingStub(
                ManagedChannelBuilder.forAddress("localhost", 9091)
                        .usePlaintext()
                        .build()
        );


        PaymentsList list;

        // List the payments
        list = stub.listPayments(Empty.getDefaultInstance());
        for (PaymentInfo payment : list.getPaymentsList()) {
            System.out.println(payment);
        }


        // Test addPayment with the valid card
        PaymentRequest validPaymentRequest = PaymentRequest.newBuilder()
                .setCardNumber("1234-1234-1234-1234")
                .setCardOwner("CardOwner")
                .setOrderIdentifier("Order123")
                .build();

        PaymentResponse validPaymentResponse = stub.addPayment(validPaymentRequest);
        System.out.println("Add Payment Response: " + validPaymentResponse.getMessage());


        // List the payments
        list = stub.listPayments(Empty.getDefaultInstance());
        for (PaymentInfo payment : list.getPaymentsList()) {
            System.out.println(payment);
        }


        // Test addPayment with an invalid card
        PaymentRequest invalidPaymentRequest = PaymentRequest.newBuilder()
                .setCardNumber("1111-1111-1111-1111")
                .setCardOwner("InvalidCardOwner")
                .setOrderIdentifier("Order456")
                .build();

        PaymentResponse invalidPaymentResponse = stub.addPayment(invalidPaymentRequest);
        System.out.println("Add Payment Response: " + invalidPaymentResponse.getMessage());


        // List the payments
       list = stub.listPayments(Empty.getDefaultInstance());
        for (PaymentInfo payment : list.getPaymentsList()) {
            System.out.println(payment);
        }

    }
}
