package cz.cvut.fit.niam1.grpc.server;

import com.google.protobuf.BoolValue;
import cz.cvut.fit.niam1.grpc.payment.*;
import io.grpc.protobuf.services.ProtoReflectionService;
import model.Cards;
import model.CardsServiceGrpc;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PaymentServiceServer {
    private static final int PORT = 9091;
    private static List<PaymentInfo> payments = new ArrayList<>();

    public static void main(String[] args) throws IOException, InterruptedException {
        Server server = ServerBuilder.forPort(PORT)
                .addService(new PaymentServiceImpl())
                .addService(ProtoReflectionService.newInstance())
                .build();

        server.start();
        System.out.println("Payment gRPC Server started on port " + PORT);
        server.awaitTermination();
    }

    @GrpcService
    @SpringBootApplication
    static class PaymentServiceImpl extends PaymentServiceGrpc.PaymentServiceImplBase {
        @Override
        public void listPayments(Empty request, StreamObserver<PaymentsList> responseObserver) {
            PaymentsList.Builder paymentsListBuilder = PaymentsList.newBuilder();
            paymentsListBuilder.addAllPayments(payments);
            responseObserver.onNext(paymentsListBuilder.build());
            responseObserver.onCompleted();
        }

        @Override
        public void addPayment(PaymentRequest request, StreamObserver<PaymentResponse> responseObserver) {
            //address and port of the remote CardsService
            String cardsServiceAddress = "ni-am.fit.cvut.cz";
            int cardsServicePort = 9090;

            ManagedChannel cardsServiceChannel = ManagedChannelBuilder.forAddress(cardsServiceAddress, cardsServicePort)
                    .usePlaintext()
                    .build();

            // Create a gRPC stub for the remote CardsService
            CardsServiceGrpc.CardsServiceBlockingStub cardsServiceStub = CardsServiceGrpc.newBlockingStub(cardsServiceChannel);

            // Create a card
            Cards.Card card = Cards.Card.newBuilder()
                    .setCardNumber(request.getCardNumber())
                    .setCardOwner(request.getCardOwner())
                    .build();

            // Make a gRPC call to the validateCard method on ni-am.fit.cvut.cz:9090 with the card
            BoolValue cardValidationResponse = cardsServiceStub.validateCard(card);

            // Wait for the response whether the card is valid
            boolean isValidCard = cardValidationResponse.getValue();

            // return "Invalid card information" if the validateCard call returned false
            if (!isValidCard) {
                responseObserver.onNext(PaymentResponse.newBuilder()
                        .setSuccess(BoolValue.newBuilder().setValue(false).build())
                        .setMessage("Invalid card information")
                        .build());
                responseObserver.onCompleted();
                return;
            }
            // if the call was true process the payment and add it to the list
            else {
                PaymentInfo newPayment = PaymentInfo.newBuilder()
                        .setCardNumber(request.getCardNumber())
                        .setCardOwner(request.getCardOwner())
                        .setOrderIdentifier(request.getOrderIdentifier())
                        .build();
                payments.add(newPayment);

                responseObserver.onNext(PaymentResponse.newBuilder()
                        .setSuccess(BoolValue.newBuilder().setValue(true).build())
                        .setMessage("Payment successful")
                        .build());
                responseObserver.onCompleted();
            }
        }



    }
}
